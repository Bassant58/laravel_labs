<?php $__env->startSection('content'); ?>
<div class="container border px-5"> 
    <h1 class="text-center mt-3"> Edit Form </h1>
    <form class="row g-3 mt-3" method="post" action="<?php echo e(route('cat.update' , ['categories' => $oneCat->id ])); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
    <div class="col-6">
      <label for="FirstName" class="form-label">Name</label>
      <input type="text" class="form-control" id="Name" name="name" placeholder="Category Name" value=" <?php echo e($oneCat->name); ?> ">
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary btn-block mb-3 ms-2 mt-4" name="edit" value="edit">Edit</button>
      <a href="<?php echo e(route('cat.index')); ?>" class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/category/editCat.blade.php ENDPATH**/ ?>