<?php $__env->startSection('content'); ?>
<div class="container border px-5"> 
    <h1 class="text-center mt-3"> Edit Form </h1>
    <form class="row g-3 mt-3" method="post" action="<?php echo e(route('art.update' , ['articles' => $oneArt->id ])); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
    <div class="col-6">
      <label for="FirstName" class="form-label">Name</label>
      <input type="text" class="form-control" id="Name" name="name" placeholder="Art Name" value=" <?php echo e($oneArt->art_name); ?> ">
    </div>
    <div class="col-12">
        <textarea name="details" id="detail" cols="40" rows="6" ><?php echo e($oneArt->details); ?></textarea>
      </div>
      <div class="col-md-12">
        <label for="" class="form-label">Is - Used</label>
        <div class="form-check form-check-inline ms-3">
          <input class="form-check-input" type="radio" name="used" id="inlineRadio1" value="1">
          <label class="form-check-label" for="inlineRadio1">True</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="used" id="inlineRadio2" value="0">
          <label class="form-check-label" for="inlineRadio2">False</label>
        </div>
       
      </div>
      <div class="col-md-6 ">
        <select class="form-select" aria-label="Default select example" name="catId">
          <option selected>Cat_Id</option>
           <?php $__currentLoopData = $catId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
           <option value="<?php echo e($item->id); ?>"> <?php echo e($item->id); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-12">
        <label for="phone" class="form-label">Slug</label>
        <input type="text" class="form-control" id="slug" placeholder="Slug" name="slug" value=" <?php echo e($oneArt->slug); ?> ">
      </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary btn-block mb-3 ms-2 mt-4" name="edit" value="edit">Edit</button>
      <a href="<?php echo e(route('art.index')); ?>" class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/article/editArticle.blade.php ENDPATH**/ ?>