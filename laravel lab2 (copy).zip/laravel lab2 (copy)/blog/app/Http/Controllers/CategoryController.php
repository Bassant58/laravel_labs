<?php

namespace App\Http\Controllers;
use App\Models\Category ;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Contracts\Service\Attribute\Required;

class CategoryController extends Controller
{
    public function index(){

        $categories =   Category::all() ; 
        return view('blog.category.category' , ['data' => $categories]) ; 
    }

    public function create(){
        return view('blog.category.addCategory');
    }

    public function store(Request $request){

         Category::create($request->all());
        
        return redirect()->route('cat.index');
    }

    public function show($id){
        // $oneCategory= Category::findOrFail($id);
        $oneCategory= Category::leftJoin('articals', 'articals.cat_id' , '=' , 'categories.id')
        // ->select('categories.id', 'categories.name' , 'articals.name')
        ->where('categories.id', '=', $id)
        ->get(['categories.name', 'articals.art_name' , 'categories.id']);
        // dd($oneCategory);
        return view('blog.category.showCat' , compact('oneCategory')) ;
        // return view('blog.category.showCat' , ['oneCat' => $oneCategory]) ;
    }

    public function edit($id){
        $singleCat = Category::findOrFail($id);
        return view('blog.category.editCat'  , ['oneCat' => $singleCat]);
    }

    public function update($id , Request $request){
              DB::table('categories')
              ->where('id', $id)
              ->update(['name' => $request->name ]);
              return redirect()->route('cat.index');
    }

    public function destroy($id){
        DB::table('categories')->where('id', '=', $id)->delete();
        return redirect()->route('cat.index');
    }
}
