<?php

namespace App\Http\Controllers;
use App\Models\Artical ;
use App\Models\Category ;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class ArticalController extends Controller
{
    public function index(){
        $articles =   Artical::all() ; 
        return view('blog.article.artical' , ['data' => $articles]) ; 
    }

    public function create(){
        $catId = Category::all();
        return view('blog.article.newArtical' , ['catId' => $catId]);
    }

    public function store(Request $request){

       $name = $request->name ;
       $details = $request->details ;
       $slug = $request->slug ;
       $cat_id = $request->catId ;
       $used= $request->used ;
        Artical::create([
           'cat_id' => $cat_id ,
           'art_name' => $name ,
           'details' => $details ,
           'is_used' => $used , 
           'slug' => $slug
        ]);
       return redirect()->route('art.index');
   }

   public function edit($id){
    $catId = Category::all();
    $singleArt = Artical::findOrFail($id);
    return view('blog.article.editArticle'  , ['oneArt' => $singleArt , 'catId' => $catId]);
}

public function update($id , Request $request){
          DB::table('articals')
          ->where('id', $id)
          ->update(['art_name' => $request->name , 'cat_id' => $request->catId , 
          'slug' => $request->slug , 'is_used' => $request->used , 'details' => $request->details]);
          return redirect()->route('art.index');
}

    public function show($id){
        
        $oneArtical= Artical::findOrFail($id);
        return view('blog.article.showArtical' , ['oneArtical' => $oneArtical]) ;
    }

    public function destroy($id){
        Artical::where('id', $id)->delete();
        return redirect()->route('art.index');
    }
}
