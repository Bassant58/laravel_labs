@extends('layout.app')
@section('content')
@foreach ($oneCategory as $item)

@endforeach
<div class="container  px-5 py-5 d-flex justify-content-center" >
    <div class="card w-50 ">
        <div class="card-body ">
            <h5 class="card-header pb-3 bg-transparent border-dark ">Category Information</h5>
            <ul class=" mt-4 pb-3 ps-5">
                <li>ID => {{$item->id}}</li>
                <li>Category Name => {{$item->name}} </li>
                @foreach ($oneCategory as $item)

                   
                    <li>Articles Attached  => {{ $item->art_name ? $item->art_name : 'empty'}}</li>

                         @endforeach
            </ul>
            <div class="card-footer bg-transparent border-dark"><a href="{{route('cat.index')}} " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a></div>
        </div>
    </div>
</div>
@endsection
