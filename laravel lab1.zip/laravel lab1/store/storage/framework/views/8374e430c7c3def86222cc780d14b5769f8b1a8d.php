<?php $__env->startSection('content'); ?>



<div class="container px-5 py-5" >
    <div class = "d-flex flex-wrap  justify-content-evenly">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card w-25 mx-3 my-3">
            <div class="card-body ">
                <h5 class="card-header pb-3 bg-transparent border-dark "> <?php echo e($products['name']); ?> Product </h5>
                <div class="card-footer bg-transparent border-dark "><a href="/product_details/<?php echo e($products['id']); ?>" class="btn btn-dark btn-block mb-3 ms-2 mt-4 ">Details</a></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab1/store/resources/views/store/home.blade.php ENDPATH**/ ?>