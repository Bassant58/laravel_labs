<?php

namespace App\Http\Controllers;
use Illuminate\Support\Arr;


use Illuminate\Http\Request;

class HomeController extends Controller
{
   public $products = [
        ['id' => 1 , 'name' => 'Watch' , 'price' => 2000],
        ['id' => 2 , 'name' => 'Phone' , 'price' => 1000],
        ['id' => 3 , 'name' => 'Camera' , 'price' => 3000],
        ['id' => 4 , 'name' => 'Laptop' , 'price' => 10000],
        ['id' => 5 , 'name' => 'Ipad' , 'price' => 5000],
        ['id' => 6 , 'name' => 'Lipstick' , 'price' => 7000],
        ['id' => 7 , 'name' => 'T-shirt' , 'price' => 9000],
        ['id' => 8 , 'name' => 'Toy' , 'price' => 100],
        ['id' => 9 , 'name' => 'Screen' , 'price' => 8000],
        ['id' => 10 , 'name' => 'HeadPhones' , 'price' => 200],
        ['id' => 11 , 'name' => 'Battery' , 'price' => 10000],
        ['id' => 12 , 'name' => 'Cards' , 'price' => 900],
    ];

    public $categories = ['Phones' , 'Watches' , 'Sport_wear' , 'Other'] ;

    public function index(){
        return view('store.home' , ['cat' => $this->categories , 'product' => $this->products]);
    }

    public function show($id){
         
        $single_product = Arr::get($this->products, $id-1);
        // dd($single_product , $id);
        
        if($single_product == null) {
            abort(404);
        }

        return view('store.product' , ['oneProduct' => $single_product , 'cat' => $this->categories]);
    }
}
