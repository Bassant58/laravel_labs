@extends('layout.store')

@section('content')

{{-- @dd($products) --}}

<div class="container px-5 py-5" >
    <div class = "d-flex flex-wrap  justify-content-evenly">
            @foreach ($product as  $products)
        <div class="card w-25 mx-3 my-3">
            <div class="card-body ">
                <h5 class="card-header pb-3 bg-transparent border-dark "> {{$products['name']}} Product </h5>
                <div class="card-footer bg-transparent border-dark "><a href="/product_details/{{$products['id']}}" class="btn btn-dark btn-block mb-3 ms-2 mt-4 ">Details</a></div>
            </div>
        </div>
        @endforeach
        </div>
    </div>
    
@endsection