<?php $__env->startSection('content'); ?>
 <div class="container border px-5"> 
      <h1 class="text-center mt-3"> Add Artical </h1>
      <form class="row g-3 mt-3" method="post" action=" <?php echo e(route('art.store')); ?> ">
        <?php echo csrf_field(); ?>
      <div class="col-6">
        <label for="FirstName" class="form-label">Name</label>
        <input type="text" class="form-control" id="Name" name="art_name" value="<?php echo e(old('art_name')); ?>" placeholder="Art Name">
        <?php $__errorArgs = ['art_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="col-6 text-danger mt-2">
            <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-12">
        <textarea name="details" id="detail" cols="40" rows="6">Details</textarea>
        <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="col-6 text-danger mt-2">
            <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-md-12">
        <label for="" class="form-label">Is - Used</label>
        <div class="form-check form-check-inline ms-3">
          <input class="form-check-input" type="radio" name="is_used" id="inlineRadio1" value="1">
          <label class="form-check-label" for="inlineRadio1">True</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="is_used" id="inlineRadio2" value="0">
          <label class="form-check-label" for="inlineRadio2">False</label>
        </div>
        <?php $__errorArgs = ['is_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="col-6 text-danger mt-2">
            <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
       
      </div>
      <div class="col-md-6 ">
        <select class="form-select" aria-label="Default select example" name="cat_id">
        
           <?php $__currentLoopData = $catId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
           <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['cat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="col-6 text-danger mt-2">
            <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-md-12">
        <label for="slug" class="form-label">Slug</label>
        <input type="text" class="form-control" id="slug" placeholder="Slug" name="slug">
        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="col-6 text-danger mt-2">
            <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary btn-block mb-3 ms-2 mt-4" name="add" value="add">Add</button>
        <a href=" <?php echo e(route('art.index')); ?> " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a>
      </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/article/newArtical.blade.php ENDPATH**/ ?>