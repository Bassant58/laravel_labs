<?php $__env->startSection('content'); ?>
<div class="container  px-5 py-5 d-flex justify-content-center" >
    <div class="card w-50 ">
        <div class="card-body ">
            <h5 class="card-header pb-3 bg-transparent border-dark ">Category Information</h5>
            <ul class=" mt-4 pb-3 ps-5">
                <li>ID => <?php echo e($oneCat['id']); ?></li>
                <li>Category Name => <?php echo e($oneCat['name']); ?> </li>
                <?php $__currentLoopData = $oneArt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                   
                    <li> Articles Attached  => <?php echo e($item->art_name ? $item->art_name : 'empty'); ?></li>

                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="card-footer bg-transparent border-dark"><a href="<?php echo e(route('cat.index')); ?> " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/category/showCat.blade.php ENDPATH**/ ?>