<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ArticalController ;



// //show all articals
Route::get('/article' , [ArticalController::class , 'index'])->name('art.index');
 
// create new article 
Route::get('/article/create' , [ArticalController::class , 'create'])->name('art.create');

// save new article
Route::post('/article' , [ArticalController::class , 'store'])->name('art.store');

//edit one article 
Route::get('/article/{articles}/edit', [ArticalController::class , 'edit'])->name('art.edit') ;

//update article
Route::put('/article/{articles}' , [ArticalController::class , 'update'])->name('art.update') ;

//show one articals
Route::get('/article/{articles}' , [ArticalController::class , 'show'])->name('art.show');

// //delete one articals
Route::delete('/article/{articles}' , [ArticalController::class , 'destroy'])->name('art.destroy');
