<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\CategoryController ;
use App\Http\Controllers\ArticalController ;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
// show categories
Route::get('/cat' , [CategoryController::class , 'index'])->name('cat.index');

// create new categories
Route::get('/cat/create' , [CategoryController::class , 'create'])->name('cat.create');

// save new categories
Route::post('/cat' , [CategoryController::class , 'store'])->name('cat.store');

//edit one category 
Route::get('/cat/{categories}/edit', [CategoryController::class , 'edit'])->name('cat.edit') ;

//update category
Route::put('/cat/{categories}' , [CategoryController::class , 'update'])->name('cat.update') ;

// show one category
Route::get('/cat/{categories}' , [CategoryController::class , 'show'])->name('cat.show');

//delete category
Route::delete('/cat/{categories}' , [CategoryController::class , 'destroy'])->name('cat.destroy') ;

*/
// ////////////////////////////////////////////////////////////////////////////

// //show all articals
Route::get('/article' , [ArticalController::class , 'index'])->name('art.index');
 
// create new article 
Route::get('/article/create' , [ArticalController::class , 'create'])->name('art.create');

// save new article
Route::post('/article' , [ArticalController::class , 'store'])->name('art.store');

//edit one article 
Route::get('/article/{articles}/edit', [ArticalController::class , 'edit'])->name('art.edit') ;

//update article
Route::put('/article/{articles}' , [ArticalController::class , 'update'])->name('art.update') ;

//show one articals
Route::get('/article/{articles}' , [ArticalController::class , 'show'])->name('art.show');

// //delete one articals
Route::delete('/article/{articles}' , [ArticalController::class , 'destroy'])->name('art.destroy');
