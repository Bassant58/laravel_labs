<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController ;

// show categories
Route::get('/cat' , [CategoryController::class , 'index'])->name('cat.index');

// create new categories
Route::get('/cat/create' , [CategoryController::class , 'create'])->name('cat.create');

// save new categories
Route::post('/cat' , [CategoryController::class , 'store'])->name('cat.store');

//edit one category 
Route::get('/cat/{categories}/edit', [CategoryController::class , 'edit'])->name('cat.edit') ;

//update category
Route::put('/cat/{categories}' , [CategoryController::class , 'update'])->name('cat.update') ;

// show one category
Route::get('/cat/{categories}' , [CategoryController::class , 'show'])->name('cat.show');

//delete category
Route::delete('/cat/{categories}' , [CategoryController::class , 'destroy'])->name('cat.destroy') ;