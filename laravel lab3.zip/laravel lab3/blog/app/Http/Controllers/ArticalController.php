<?php

namespace App\Http\Controllers;
use App\Models\Artical ;
use App\Http\Requests\BlogArticleRequest;
use App\Models\Category ;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class ArticalController extends Controller
{
    public function index(){
        $articles =   Artical::all() ; 
        return view('blog.article.artical' , ['data' => $articles]) ; 
    }

    public function create(){
        $catId = Category::all();
        return view('blog.article.newArtical' , ['catId' => $catId]);
    }
    
    public function store(BlogArticleRequest $request){

            $validated = $request->validated();
            Artical::create([
               'cat_id' => $validated['cat_id'] ,
               'art_name' => $validated['art_name'] ,
               'details' => $validated['details'] ,
               'is_used' => $validated['is_used'] , 
               'slug' => $validated['slug']
            ]);
    
           return redirect()->route('art.index');
       }


   public function edit($id){
    $catId = Category::all();
    $singleArt = Artical::findOrFail($id);
    return view('blog.article.editArticle'  , ['oneArt' => $singleArt , 'catId' => $catId]);
}

public function update($id , BlogArticleRequest $request){
     $validated = $request->validated();
          DB::table('articals')
          ->where('id', $id)
          ->update(['art_name' => $validated['art_name'] , 'cat_id' => $validated['cat_id'] , 
          'slug' => $validated['slug'] , 'is_used' => $validated['is_used'] , 'details' => $validated['details'] ]);
          return redirect()->route('art.index');
}

    public function show($id){

        $cat = Category::find($id);
        $oneArtical= Artical::findOrFail($id);
        // dd($cat);
        // $art = Artical::whereBelongsTo($cat)->get();
        // dd($art);
        return view('blog.article.showArtical' , [
            'art' => $oneArtical,
            'cat' => $cat
        ]);
        
        // return view('blog.article.showArtical' , ['oneArtical' => $oneArtical]) ;
    }

    public function destroy($id){
        Artical::where('id', $id)->delete();
        return redirect()->route('art.index');
    }
}


