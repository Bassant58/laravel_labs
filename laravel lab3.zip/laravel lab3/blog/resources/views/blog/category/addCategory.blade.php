@extends('layout.app')
@section('content')
 <div class="container border px-5"> 
      <h1 class="text-center mt-3"> Add Form </h1>
      <form class="row g-3 mt-3" method="post" action="{{route('cat.store')}}">
        @csrf
      <div class="col-6">
        <label for="FirstName" class="form-label">Name</label>
        <input type="text" class="form-control" id="Name" name="name" placeholder="Category Name">
        @error('name')
        <div class="col-6 text-danger mt-2">
              {{$message}}
        </div>
        @enderror
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary btn-block mb-3 ms-2 mt-4" name="add" value="add">Add</button>
        <a href=" {{route('cat.index')}} " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a>
      </div>
    </form>
</div>

@endsection