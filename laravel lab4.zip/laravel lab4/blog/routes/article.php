<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ArticalController ;



// //show all articals
Route::get('/article' , [ArticalController::class , 'index'])->middleware(['auth'])->name('art.index');
 
// create new article 
Route::get('/article/create' , [ArticalController::class , 'create'])->middleware(['auth'])->name('art.create');

// save new article
Route::post('/article' , [ArticalController::class , 'store'])->middleware(['auth'])->name('art.store');


// // save new article
// Route::post('/article' , [ArticalController::class , 'send'])->middleware(['auth'])->name('art.send');


//edit one article 
Route::get('/article/{articles}/edit', [ArticalController::class , 'edit'])->middleware(['auth'])->name('art.edit') ;

//update article
Route::put('/article/{articles}' , [ArticalController::class , 'update'])->middleware(['auth'])->name('art.update') ;

//show one articals
Route::get('/article/{articles}' , [ArticalController::class , 'show'])->middleware(['auth'])->name('art.show');

// //delete one articals
Route::delete('/article/{articles}' , [ArticalController::class , 'destroy'])->middleware(['auth'])->name('art.destroy');


Route::get('/send' , [ArticalController::class , 'form']);

Route::post('/send' , [ArticalController::class , 'send'])->name('art.send');





require __DIR__.'/auth.php';
