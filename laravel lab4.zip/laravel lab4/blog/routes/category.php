<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController ;

// show categories
Route::get('/cat' , [CategoryController::class , 'index'])->middleware(['auth' , 'is_admin' , 'age'])->name('cat.index');

// create new categories
Route::get('/cat/create' , [CategoryController::class , 'create'])->middleware(['auth' , 'is_admin' , 'age'])->name('cat.create');

// save new categories
Route::post('/cat' , [CategoryController::class , 'store'])->middleware(['auth' , 'is_admin' , 'age'])->name('cat.store');

//edit one category 
Route::get('/cat/{categories}/edit', [CategoryController::class , 'edit'])->middleware(['auth' , 'is_admin' ,'age'])->name('cat.edit') ;

//update category
Route::put('/cat/{categories}' , [CategoryController::class , 'update'])->middleware(['auth' , 'is_admin' ,'age'])->name('cat.update') ;

// show one category
Route::get('/cat/{categories}' , [CategoryController::class , 'show'])->middleware(['auth' , 'is_admin' ,'age'])->name('cat.show');

//delete category
Route::delete('/cat/{categories}' , [CategoryController::class , 'destroy'])->middleware(['auth' , 'is_admin' ,'age'])->name('cat.destroy') ;


require __DIR__.'/auth.php';