@extends('layout.app') 
@section('content')
  <div class="container border px-5 py-5 ">
    <a href=" {{route('cat.create')}} " class="btn btn-dark btn-block mb-3 mt-2">Add Category</a>
  <table class="table">

  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">delete</th>
      <th scope="col">show</th>
      <th scope="col">edit</th>
    </tr>
  </thead>
  <tbody>
      @foreach ($data as $item)
      {{-- @dd($data) --}}
        <tr>
            <th scope="row"> {{$item->id}} </th>
            <td>  {{$item->name}} </td>
            <td>
              <form method="post" action="{{ route('cat.destroy' , ['categories' => $item->id]) }}">
                  @method('DELETE')
                  @csrf
              <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-block" name="delete" id="delete">Delete</button>
            </form>
            </td>
            <td> <a href=" {{route('cat.show' , ['categories' => $item->id ])}} " class="btn btn-primary btn-block">Show</a></td>
            <td> <a href=" {{route('cat.edit' , ['categories' => $item->id ])}}" class="btn btn-dark btn-block">Edit</a></td>
        </tr>
        @endforeach
  </tbody>
</table>
</div>
<div class="d-flex justify-content-end mt-5 me-5 mb-3">
{!! $data->links() !!}
</div>
  @endsection
 










