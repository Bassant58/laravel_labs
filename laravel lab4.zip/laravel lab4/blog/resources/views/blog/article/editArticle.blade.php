@extends('layout.app')
@section('content')
<div class="container border px-5"> 
    <h1 class="text-center mt-3"> Edit Form </h1>
    <form class="row g-3 mt-3" method="post" action="{{route('art.update' , ['articles' => $oneArt->id ])}}">
      @csrf
      @method('PUT')
    <div class="col-6">
      <label for="FirstName" class="form-label">Name</label>
      <input type="text" class="form-control" id="Name" name="art_name" placeholder="Art Name" value=" {{$oneArt->art_name}} ">
      @error('art_name')
      <div class="col-6 text-danger mt-2">
            {{$message}}
      </div>
      @enderror
    </div>
    <div class="col-12">
        <textarea name="details" id="detail" cols="40" rows="6" >{{$oneArt->details}}</textarea>
        @error('details')
      <div class="col-6 text-danger mt-2">
            {{$message}}
      </div>
      @enderror
      </div>
      <div class="col-md-12">
        <label for="" class="form-label">Is - Used</label>
        <div class="form-check form-check-inline ms-3">
          <input class="form-check-input" type="radio" name="is_used" id="inlineRadio1" value="1">
          <label class="form-check-label" for="inlineRadio1">True</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="is_used" id="inlineRadio2" value="0">
          <label class="form-check-label" for="inlineRadio2">False</label>
        </div>
        @error('is_used')
        <div class="col-6 text-danger mt-2">
              {{$message}}
        </div>
        @enderror
       
      </div>
      <div class="col-md-6 ">
        <select class="form-select" aria-label="Default select example" name="cat_id">
         
           @foreach ($catId as $item)
               
           <option value="{{$item->id}}"> {{$item->name}}</option>
           @endforeach
        </select>
        @error('cat_id')
      <div class="col-6 text-danger mt-2">
            {{$message}}
      </div>
      @enderror
      </div>
      <div class="col-md-12">
        <label for="phone" class="form-label">Slug</label>
        <input type="text" class="form-control" id="slug" placeholder="Slug" name="slug" value=" {{$oneArt->slug}} ">
        {{-- @error('slug')
        <div class="col-6 text-danger mt-2">
              {{$message}}
        </div>
        @enderror --}}
      </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary btn-block mb-3 ms-2 mt-4" name="edit" value="edit">Edit</button>
      <a href="{{route('art.index')}}" class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a>
    </div>
  </form>
</div>
@endsection