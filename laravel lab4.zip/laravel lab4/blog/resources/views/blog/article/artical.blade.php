@extends('layout.app') 
@section('content')
  <div class="container border px-5 py-5">
    <a href=" {{route('art.create')}} " class="btn btn-dark btn-block mb-3 mt-2">Add Article</a>
  <table class="table">

  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">delete</th>
      <th scope="col">show</th>
      <th scope="col">edit</th>
    </tr>
  </thead>
  <tbody>
      @foreach ($data as $item)
        <tr>
            <th scope="row"> {{$item->id}} </th>
            <td>  {{$item->art_name}} </td>
            <td>
              <form method="post" action=" {{route('art.destroy' , ['articles' => $item->id ])}} ">
                  @method('DELETE')
                  @csrf
              <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-block" name="delete" id="delete">Delete</button>
            </form>
            </td>
            <td> <a href=" {{route('art.show' , ['articles' => $item->id ])}} " class="btn btn-primary btn-block">Show</a></td>
            <td> <a href="  {{route('art.edit' , ['articles' => $item->id ])}} " class="btn btn-dark btn-block">Edit</a></td>
        </tr>
        @endforeach
  </tbody>
</table>
  </div>
</div>
<div class="d-flex justify-content-center mt-5 me-5 mb-3">
{!! $data->links() !!}
</div>
  @endsection

