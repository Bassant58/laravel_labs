@extends('layout.app')
@section('content')
    
<div class="container  px-5 py-5 d-flex justify-content-center" >
    <div class="card w-50 ">
        <div class="card-body ">
            <h5 class="card-header pb-3 bg-transparent border-dark ">Your Information</h5>
            <ul class=" mt-4 pb-3 ps-5">
                <li>ID => {{$art->id}}</li>
                <li>Name => {{$art->art_name}} </li>
                <li>Details => {{$art->details}}</li>
                <li>Slug => {{$art->slug}}</li>
                <li>Is_Used=> {{$art->is_used == 1 ? "True" : 'False'}} </li>
                <li>Category name => {{$art->category->name}}</li>
            </ul>
            <div class="card-footer bg-transparent border-dark"><a href="{{route('art.index')}} " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a></div>
        </div>
    </div>
</div>
@endsection

