<?php $__env->startSection('content'); ?>
    
<div class="container  px-5 py-5 d-flex justify-content-center" >
    <div class="card w-50 ">
        <div class="card-body ">
            <h5 class="card-header pb-3 bg-transparent border-dark ">Your Information</h5>
            <ul class=" mt-4 pb-3 ps-5">
                <li>ID => <?php echo e($oneArtical->id); ?></li>
                <li>Name => <?php echo e($oneArtical->name); ?> </li>
                <li>Details => <?php echo e($oneArtical->details); ?></li>
                <li>Slug => <?php echo e($oneArtical->slug); ?></li>
                <li>Is_Used=> <?php echo e($oneArtical->is_used); ?></li>
                <li>Category_Id => <?php echo e($oneArtical->cat_id); ?></li>
            </ul>
            <div class="card-footer bg-transparent border-dark"><a href="<?php echo e(route('artical.index')); ?> " class="btn btn-danger btn-block mb-3 ms-2 mt-4 ">Go Back</a></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/showArtical.blade.php ENDPATH**/ ?>