<?php echo e($slot); ?>

<?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>