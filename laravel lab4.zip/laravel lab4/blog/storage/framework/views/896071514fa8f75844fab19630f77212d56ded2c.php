<?php $__env->startComponent('mail::message'); ?>
# Introduction

The body of your message.

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8000/send']); ?>
Let's Start 
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/emails/register.blade.php ENDPATH**/ ?>