 
<?php $__env->startSection('content'); ?>
  <div class="container border px-5 py-5">
  <table class="table">

  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">delete</th>
      <th scope="col">show</th>
      <th scope="col">edit</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"> <?php echo e($item->id); ?> </th>
            <td>  <?php echo e($item->name); ?> </td>
            <td>
              <form method="post" action=" <?php echo e(route('article.destroy' , ['artical' => $item->id ])); ?> ">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
              <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-block" name="delete" id="delete">Delete</button>
            </form>
            </td>
            <td> <a href=" /articals/<?php echo e($item->id); ?> " class="btn btn-primary btn-block">Show</a></td>
            <td> <a href="" class="btn btn-dark btn-block">Edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  </div>
  <?php $__env->stopSection(); ?>
  <script>
    function x(){
     return  confirm(' sure ?! ')
    
    }
  </script>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/resources/views/blog/artical.blade.php ENDPATH**/ ?>