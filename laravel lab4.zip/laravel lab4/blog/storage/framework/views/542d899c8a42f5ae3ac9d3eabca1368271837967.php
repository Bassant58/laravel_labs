<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/bassant/ITI/laravel/laravel lab2/blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>