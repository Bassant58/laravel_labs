<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model;

class Artical extends Model
{
    use HasFactory;
    protected $table = "articals";


    protected $fillable = ['art_name' , 'details' , 'is_used' ,  'cat_id' , 'slug'];


    public function category(){
        return $this->belongsTo(Category::class , 'cat_id');
    }
}
