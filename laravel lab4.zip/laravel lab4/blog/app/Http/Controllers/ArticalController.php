<?php

namespace App\Http\Controllers;
use App\Models\Artical ;
use App\Http\Requests\BlogArticleRequest;
use App\Models\Category ;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\Register;

class ArticalController extends Controller
{
    public function index(){
        // $articles =   Artical::all() ;
        $articles =   Artical::paginate(10) ; 
    //     $birth_date = '1999-8-5';
    //    $years = Carbon::parse($birth_date)->age;
    //    dd($years);
        return view('blog.article.artical' , ['data' => $articles]) ; 
    }

    public function create(){
        $catId = Category::all();
        return view('blog.article.newArtical' , ['catId' => $catId]);
    }
    
    public function store(BlogArticleRequest $request){

            $validated = $request->validated();
            Artical::create([
               'cat_id' => $validated['cat_id'] ,
               'art_name' => $validated['art_name'] ,
               'details' => $validated['details'] ,
               'is_used' => $validated['is_used'] , 
               'slug' => $validated['slug']
            ]);

            // Mail::to('soso@gmail.com')->send(new Register());
    
           return redirect()->route('art.index');
       }


   public function edit($id){
    $catId = Category::all();
    $singleArt = Artical::findOrFail($id);
    return view('blog.article.editArticle'  , ['oneArt' => $singleArt , 'catId' => $catId]);
}

public function update($id , BlogArticleRequest $request){
     $validated = $request->validated();
          DB::table('articals')
          ->where('id', $id)
          ->update(['art_name' => $validated['art_name'] , 'cat_id' => $validated['cat_id'] , 
          'slug' => $validated['slug'] , 'is_used' => $validated['is_used'] , 'details' => $validated['details'] ]);
          return redirect()->route('art.index');
}

    public function show($id){

        // $cat = Category::find($id);

        // first i get the article 
        // then i add function category to get the category which that article belongs to 
        // or i can write directly in the view 
        // $cat = Artical::find($id)->category;
        // dd($cat);
        $oneArtical= Artical::findOrFail($id);
        // dd($art);
        return view('blog.article.showArtical' , [ 'art' => $oneArtical
            // 'cat' => $cat
          ]);
        
        // return view('blog.article.showArtical' , ['oneArtical' => $oneArtical]) ;
    }

    public function destroy($id){
        Artical::where('id', $id)->delete();
        return redirect()->route('art.index');
    }

    
    
    public function form(){ 
        return view('blog.article.form');
        
    }
    
    public function send(Request $request){
       
        // dd($request->email);

        Mail::to($request->email)->send(new Register());
    
        return redirect()->back();
    
    }
}


